# Lumina Worker v4 — Deployment Guide

## Neue Endpoints
- `/headers?url=...` — Response-Headers + Security-Check (kein Browser Rendering nötig)
- `/deep?url=...` — JS-gerenderten HTML via Cloudflare Browser Rendering
- `/screenshot?url=...&device=desktop|mobile|tablet&full=0|1` — Screenshot via Browser Rendering

## Schritt 1: Browser Rendering API Token erstellen
1. Gehe zu https://dash.cloudflare.com/profile/api-tokens
2. "Create Token" → "Custom Token"
3. Name: `lumina-browser-rendering`
4. Permissions: `Account` → `Browser Rendering` → `Edit`
5. Account Resources: Dein Account
6. "Continue to Summary" → "Create Token"
7. **Token kopieren** (wird nur einmal angezeigt!)

## Schritt 2: Worker-Code deployen
1. Gehe zu https://dash.cloudflare.com → Workers & Pages → lumina-proxy
2. "Edit Code" klicken
3. Gesamten Code durch den Inhalt von `worker-v4.js` ersetzen
4. "Save and Deploy"

## Schritt 3: Secret setzen
1. In lumina-proxy → Settings → Variables & Secrets
2. "Add Variable" → Type: "Secret"
3. Name: `CF_BR_TOKEN`
4. Value: Der API Token aus Schritt 1
5. "Save"

## Schritt 4: Testen
```
# Health check
curl https://lumina-proxy.julien-elbahy.workers.dev/

# Headers endpoint (funktioniert sofort)
curl "https://lumina-proxy.julien-elbahy.workers.dev/headers?url=https://lumina-seo.com"

# Deep scan (funktioniert nach Secret-Setup)
curl "https://lumina-proxy.julien-elbahy.workers.dev/deep?url=https://lumina-seo.com"

# Screenshot
curl "https://lumina-proxy.julien-elbahy.workers.dev/screenshot?url=https://lumina-seo.com&device=desktop" -o screenshot.png
```

## Kosten
- `/headers`: Kostenlos (normaler Worker-Fetch, kein Browser Rendering)
- `/deep` + `/screenshot`: 
  - Free Plan: 10 Min/Tag (~120 Scans)
  - Paid ($5/Mo): 10h/Monat (~7.200 Scans)
  - Darüber: $0.09/Stunde
