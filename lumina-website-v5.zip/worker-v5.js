// Lumina SEO — Full Proxy Worker v5.0
// Endpoints:
//   GET /fetch?url=           → Raw HTML
//   GET /check?url=&bot=      → Bot server check  
//   GET /headers?url=         → Response headers + security
//   GET /deep?url=            → JS-rendered HTML (Browser Rendering)
//   GET /screenshot?url=      → Screenshot (Browser Rendering)
//   GET /redirect?url=        → Follow redirect chain
//   GET /dfs?endpoint=&...    → DataForSEO proxy (rate limited, or user key)
//   GET /                     → Health

const ALLOWED_ORIGINS = [
  'https://lumina-seo.com','https://www.lumina-seo.com',
  'https://lumina-website-01p.pages.dev',
  'http://localhost:8080','http://localhost:3000','http://127.0.0.1:8080',
];
const BLOCKED_HOSTS = [
  'localhost','127.0.0.1','0.0.0.0','10.','172.16.','172.17.','172.18.',
  '172.19.','172.20.','172.21.','172.22.','172.23.','172.24.','172.25.',
  '172.26.','172.27.','172.28.','172.29.','172.30.','172.31.','192.168.',
  'workers.dev','lumina-proxy',
];
const BOT_AGENTS = {
  'googlebot':'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
  'bingbot':'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)',
  'duckduckbot':'Mozilla/5.0 (compatible; DuckDuckBot/1.0; +https://duckduckgo.com/duckduckbot)',
  'yandexbot':'Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)',
  'baiduspider':'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)',
  'gptbot':'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.0; +https://openai.com/gptbot)',
  'oai-searchbot':'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; OAI-SearchBot/1.0; +https://openai.com/searchbot)',
  'chatgpt-user':'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; ChatGPT-User/1.0; +https://openai.com/bot)',
  'claudebot':'Mozilla/5.0 (compatible; ClaudeBot/1.0; +https://anthropic.com/claudebot)',
  'claude-searchbot':'Mozilla/5.0 (compatible; Claude-SearchBot/1.0; +https://anthropic.com/claude-searchbot)',
  'claude-user':'Mozilla/5.0 (compatible; Claude-User/1.0; +https://anthropic.com/claude-user)',
  'perplexitybot':'Mozilla/5.0 (compatible; PerplexityBot/1.0; +https://www.perplexity.ai/perplexitybot)',
  'google-extended':'Mozilla/5.0 (compatible; Google-Extended; +http://www.google.com/bot.html)',
  'xai-web-crawler':'Mozilla/5.0 (compatible; xAI-Web-Crawler/1.0; +https://x.ai/crawler)',
  'mistralai-user':'Mozilla/5.0 (compatible; MistralAI-User/1.0; +https://mistral.ai)',
  'applebot-extended':'Mozilla/5.0 (compatible; Applebot-Extended/0.1; +http://www.apple.com/go/applebot)',
  'ccbot':'CCBot/2.0 (https://commoncrawl.org/faq/)',
  'cohere-ai':'CohereBot/1.0 (+https://cohere.com/)',
  'bytespider':'Mozilla/5.0 (Linux; Android 5.0) AppleWebKit/537.36 (compatible; Bytespider; https://zhanzhang.toutiao.com/)',
  'meta-external':'Mozilla/5.0 (compatible; Meta-ExternalAgent/1.0; +https://developers.facebook.com/docs/sharing/webmasters/crawler)',
  'applebot':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/600.2.5 (compatible; Applebot/0.1; +http://www.apple.com/go/applebot)',
  'amazonbot':'Mozilla/5.0 (compatible; Amazonbot/0.1; +https://developer.amazon.com/support/amazonbot)',
  'bravebot':'Mozilla/5.0 (compatible; BraveBot/1.0; +https://brave.com/)',
  'youbot':'Mozilla/5.0 (compatible; YouBot/1.0; +https://you.com)',
};

const CF_ACCOUNT_ID = '045957bc690a89607c5ced094e3d11e4';
const DFS_DAILY_LIMIT = 5;

// ── Rate Limiter (in-memory for general endpoints) ──
const rateLimitMap = new Map();
const RATE_LIMIT = 30;
const RATE_WINDOW = 60_000;

function isRateLimited(ip) {
  const now = Date.now();
  const entry = rateLimitMap.get(ip);
  if (!entry || now - entry.start > RATE_WINDOW) {
    rateLimitMap.set(ip, { start: now, count: 1 });
    if (rateLimitMap.size > 10000) {
      for (const [key, val] of rateLimitMap) {
        if (now - val.start > RATE_WINDOW) rateLimitMap.delete(key);
      }
    }
    return false;
  }
  entry.count++;
  return entry.count > RATE_LIMIT;
}

function isAllowedOrigin(origin) {
  if (!origin) return false;
  if (origin.startsWith('chrome-extension://')) return true;
  return ALLOWED_ORIGINS.some(o => origin.startsWith(o));
}
function getCorsHeaders(origin) {
  return {
    'Access-Control-Allow-Origin': isAllowedOrigin(origin) ? origin : 'https://lumina-seo.com',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-DFS-Key',
    'Access-Control-Max-Age': '86400',
  };
}
function jsonResponse(data, status, origin) {
  return new Response(JSON.stringify(data), {
    status, headers: { 'Content-Type': 'application/json', ...getCorsHeaders(origin) },
  });
}
function validateTargetUrl(targetUrl) {
  if (!targetUrl) return { error: 'Missing ?url=' };
  let parsed;
  try { parsed = new URL(targetUrl); if (!['http:', 'https:'].includes(parsed.protocol)) throw 0; } catch { return { error: 'Invalid URL' }; }
  if (BLOCKED_HOSTS.some(h => parsed.hostname.startsWith(h) || parsed.hostname.includes(h))) return { error: 'Blocked host' };
  return { parsed };
}

// ── KV Rate Limiter for DataForSEO ──
async function getDfsUsage(ip, kv) {
  const today = new Date().toISOString().split('T')[0];
  const key = `dfs:${ip}:${today}`;
  const val = await kv.get(key);
  return val ? parseInt(val) : 0;
}
async function incrementDfsUsage(ip, kv) {
  const today = new Date().toISOString().split('T')[0];
  const key = `dfs:${ip}:${today}`;
  const current = await getDfsUsage(ip, kv);
  await kv.put(key, String(current + 1), { expirationTtl: 86400 });
  return current + 1;
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: getCorsHeaders(origin) });
    const url = new URL(request.url);

    // ══ Health ══
    if (url.pathname === '/' || url.pathname === '/health') {
      return jsonResponse({ status: 'ok', service: 'lumina-proxy', version: '5.0',
        endpoints: ['/fetch','/check','/headers','/deep','/screenshot','/redirect','/dfs'],
        bots: Object.keys(BOT_AGENTS).length }, 200, origin);
    }

    // ══ /check — Bot Server Check ══
    if (url.pathname === '/check') {
      const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
      if (isRateLimited(ip)) return jsonResponse({ error: 'Rate limited.' }, 429, origin);
      const targetUrl = url.searchParams.get('url');
      const bot = (url.searchParams.get('bot') || 'googlebot').toLowerCase();
      const { error, parsed } = validateTargetUrl(targetUrl);
      if (error) return jsonResponse({ error }, 400, origin);
      const userAgent = BOT_AGENTS[bot] || BOT_AGENTS['googlebot'];
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 10000);
      try {
        const resp = await fetch(parsed.href, { method: 'GET', headers: { 'User-Agent': userAgent }, redirect: 'follow', signal: controller.signal });
        clearTimeout(timeout);
        return jsonResponse({ statusCode: resp.status, statusText: resp.statusText, bot, url: parsed.href }, 200, origin);
      } catch (err) {
        clearTimeout(timeout);
        return jsonResponse({ statusCode: 0, bot, error: err.name === 'AbortError' ? 'Timeout' : err.message }, 200, origin);
      }
    }

    // ══ /fetch — Raw HTML ══
    if (url.pathname === '/fetch') {
      if (!isAllowedOrigin(origin) && !ALLOWED_ORIGINS.some(o => (request.headers.get('Referer') || '').startsWith(o)))
        return jsonResponse({ error: 'Forbidden' }, 403, origin);
      const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
      if (isRateLimited(ip)) return jsonResponse({ error: 'Rate limited.' }, 429, origin);
      const { error, parsed } = validateTargetUrl(url.searchParams.get('url'));
      if (error) return jsonResponse({ error }, 400, origin);
      const start = Date.now();
      try {
        const resp = await fetch(parsed.href, {
          headers: { 'User-Agent': 'Mozilla/5.0 (compatible; LuminaSEO/1.0; +https://lumina-seo.com)', 'Accept': 'text/html,application/xhtml+xml', 'Accept-Language': 'en-US,en;q=0.9,de;q=0.8' },
          redirect: 'follow', cf: { cacheTtl: 300, cacheEverything: true },
        });
        const ct = resp.headers.get('Content-Type') || '';
        if (!ct.includes('text/') && !ct.includes('html') && !ct.includes('xml')) return jsonResponse({ error: 'Not HTML', contentType: ct }, 400, origin);
        const html = await resp.text();
        if (html.length > 2_000_000) return jsonResponse({ error: 'Page too large' }, 400, origin);
        return jsonResponse({ html, status: resp.status, url: resp.url, time: Date.now() - start }, 200, origin);
      } catch (err) { return jsonResponse({ error: 'Fetch failed: ' + err.message }, 502, origin); }
    }

    // ══ /headers — Response Headers + Security ══
    if (url.pathname === '/headers') {
      if (!isAllowedOrigin(origin) && !ALLOWED_ORIGINS.some(o => (request.headers.get('Referer') || '').startsWith(o)))
        return jsonResponse({ error: 'Forbidden' }, 403, origin);
      const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
      if (isRateLimited(ip)) return jsonResponse({ error: 'Rate limited.' }, 429, origin);
      const { error, parsed } = validateTargetUrl(url.searchParams.get('url'));
      if (error) return jsonResponse({ error }, 400, origin);
      const start = Date.now();
      try {
        const resp = await fetch(parsed.href, { method: 'HEAD', headers: { 'User-Agent': 'Mozilla/5.0 (compatible; LuminaSEO/1.0; +https://lumina-seo.com)' }, redirect: 'follow' });
        const headers = {};
        for (const [key, value] of resp.headers.entries()) headers[key.toLowerCase()] = value;
        return jsonResponse({
          url: parsed.href, statusCode: resp.status, statusText: resp.statusText,
          security: {
            hsts: headers['strict-transport-security'] || null, csp: headers['content-security-policy'] || null,
            xFrameOptions: headers['x-frame-options'] || null, xContentType: headers['x-content-type-options'] || null,
            referrerPolicy: headers['referrer-policy'] || null, permissionsPolicy: headers['permissions-policy'] || null,
            xXssProtection: headers['x-xss-protection'] || null,
            crossOriginOpenerPolicy: headers['cross-origin-opener-policy'] || null,
            crossOriginEmbedderPolicy: headers['cross-origin-embedder-policy'] || null,
            crossOriginResourcePolicy: headers['cross-origin-resource-policy'] || null,
          },
          tech: { server: headers['server'] || null, poweredBy: headers['x-powered-by'] || null, cfRay: headers['cf-ray'] || null, via: headers['via'] || null },
          redirect: { finalUrl: resp.url, redirected: resp.url !== parsed.href, statusCode: resp.status },
          headers, time: Date.now() - start,
        }, 200, origin);
      } catch (err) { return jsonResponse({ error: 'Headers fetch failed: ' + err.message }, 502, origin); }
    }

    // ══ /deep — JS-rendered HTML via Browser Rendering ══
    if (url.pathname === '/deep') {
      if (!isAllowedOrigin(origin) && !ALLOWED_ORIGINS.some(o => (request.headers.get('Referer') || '').startsWith(o)))
        return jsonResponse({ error: 'Forbidden' }, 403, origin);
      const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
      if (isRateLimited(ip)) return jsonResponse({ error: 'Rate limited.' }, 429, origin);
      const { error, parsed } = validateTargetUrl(url.searchParams.get('url'));
      if (error) return jsonResponse({ error }, 400, origin);
      const apiToken = env.CF_BR_TOKEN;
      if (!apiToken) return jsonResponse({ error: 'Browser Rendering not configured.' }, 500, origin);
      const start = Date.now();
      try {
        const brResp = await fetch(`https://api.cloudflare.com/client/v4/accounts/${CF_ACCOUNT_ID}/browser-rendering/content`, {
          method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiToken}` },
          body: JSON.stringify({ url: parsed.href, goToOptions: { waitUntil: 'networkidle2', timeout: 15000 }, rejectResourceTypes: ['image', 'media', 'font'] }),
        });
        if (!brResp.ok) return jsonResponse({ error: 'Browser Rendering error: ' + brResp.status }, 502, origin);
        const html = await brResp.text();
        if (html.length > 3_000_000) return jsonResponse({ error: 'Rendered page too large' }, 400, origin);
        return jsonResponse({ html, rendered: true, url: parsed.href, time: Date.now() - start, browserMs: parseInt(brResp.headers.get('X-Browser-Ms-Used') || '0') }, 200, origin);
      } catch (err) { return jsonResponse({ error: 'Deep scan failed: ' + err.message }, 502, origin); }
    }

    // ══ /screenshot — Screenshot via Browser Rendering ══
    if (url.pathname === '/screenshot') {
      if (!isAllowedOrigin(origin) && !ALLOWED_ORIGINS.some(o => (request.headers.get('Referer') || '').startsWith(o)))
        return jsonResponse({ error: 'Forbidden' }, 403, origin);
      const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
      if (isRateLimited(ip)) return jsonResponse({ error: 'Rate limited.' }, 429, origin);
      const { error, parsed } = validateTargetUrl(url.searchParams.get('url'));
      if (error) return jsonResponse({ error }, 400, origin);
      const apiToken = env.CF_BR_TOKEN;
      if (!apiToken) return jsonResponse({ error: 'Browser Rendering not configured.' }, 500, origin);
      const device = (url.searchParams.get('device') || 'desktop').toLowerCase();
      const viewport = device === 'mobile' ? { width: 390, height: 844, deviceScaleFactor: 2 }
        : device === 'tablet' ? { width: 834, height: 1194, deviceScaleFactor: 2 }
        : { width: 1440, height: 900, deviceScaleFactor: 1 };
      try {
        const brResp = await fetch(`https://api.cloudflare.com/client/v4/accounts/${CF_ACCOUNT_ID}/browser-rendering/screenshot`, {
          method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiToken}` },
          body: JSON.stringify({ url: parsed.href, goToOptions: { waitUntil: 'networkidle2', timeout: 20000 }, viewport, screenshotOptions: { fullPage: url.searchParams.get('full') === '1', type: 'png' } }),
        });
        if (!brResp.ok) return jsonResponse({ error: 'Screenshot error: ' + brResp.status }, 502, origin);
        return new Response(await brResp.arrayBuffer(), { status: 200, headers: { 'Content-Type': 'image/png', 'Cache-Control': 'public, max-age=300', ...getCorsHeaders(origin) } });
      } catch (err) { return jsonResponse({ error: 'Screenshot failed: ' + err.message }, 502, origin); }
    }

    // ══ /redirect — Follow redirect chain ══
    if (url.pathname === '/redirect') {
      if (!isAllowedOrigin(origin) && !ALLOWED_ORIGINS.some(o => (request.headers.get('Referer') || '').startsWith(o)))
        return jsonResponse({ error: 'Forbidden' }, 403, origin);
      const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
      if (isRateLimited(ip)) return jsonResponse({ error: 'Rate limited.' }, 429, origin);
      const { error, parsed } = validateTargetUrl(url.searchParams.get('url'));
      if (error) return jsonResponse({ error }, 400, origin);

      const chain = [];
      let currentUrl = parsed.href;
      const maxHops = 10;

      for (let i = 0; i < maxHops; i++) {
        try {
          const resp = await fetch(currentUrl, {
            method: 'HEAD',
            headers: { 'User-Agent': 'Mozilla/5.0 (compatible; LuminaSEO/1.0; +https://lumina-seo.com)' },
            redirect: 'manual',
          });
          const location = resp.headers.get('location');
          chain.push({
            url: currentUrl,
            statusCode: resp.status,
            statusText: resp.statusText,
            headers: {
              location: location || null,
              server: resp.headers.get('server') || null,
            },
          });
          if (resp.status >= 300 && resp.status < 400 && location) {
            // Resolve relative redirects
            try { currentUrl = new URL(location, currentUrl).href; } catch { currentUrl = location; }
          } else {
            break; // Final destination
          }
        } catch (err) {
          chain.push({ url: currentUrl, statusCode: 0, error: err.message });
          break;
        }
      }

      return jsonResponse({
        originalUrl: parsed.href,
        finalUrl: chain.length > 0 ? chain[chain.length - 1].url : parsed.href,
        hops: chain.length - 1,
        chain,
        isHttpToHttps: parsed.href.startsWith('http://') && chain.length > 0 && chain[chain.length - 1].url.startsWith('https://'),
      }, 200, origin);
    }

    // ══ /dfs — DataForSEO Proxy with rate limiting ══
    if (url.pathname === '/dfs') {
      if (!isAllowedOrigin(origin) && !ALLOWED_ORIGINS.some(o => (request.headers.get('Referer') || '').startsWith(o)))
        return jsonResponse({ error: 'Forbidden' }, 403, origin);

      const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
      const endpoint = url.searchParams.get('endpoint'); // e.g. "serp/google/organic/live/regular"
      if (!endpoint) return jsonResponse({ error: 'Missing ?endpoint=' }, 400, origin);

      // Whitelist allowed DFS endpoints
      const allowedEndpoints = [
        'serp/google/organic/live/regular',
        'keywords_data/google_ads/search_volume/live',
        'keywords_data/google_ads/keywords_for_keywords/live',
      ];
      if (!allowedEndpoints.includes(endpoint)) return jsonResponse({ error: 'Endpoint not allowed' }, 403, origin);

      // Check for user-provided key (bypasses our limits)
      const userKey = request.headers.get('X-DFS-Key') || url.searchParams.get('dfs_key') || '';

      let dfsAuth;
      if (userKey) {
        // User provides their own key — no rate limit
        dfsAuth = userKey;
      } else {
        // Use our key — check KV rate limit
        const ourKey = env.DFS_API_KEY;
        if (!ourKey) return jsonResponse({ error: 'DataForSEO not configured. Please provide your own API key.', needsKey: true }, 403, origin);

        // KV rate limiting
        const kv = env.RATE_LIMITS;
        if (!kv) return jsonResponse({ error: 'Rate limit store not available' }, 500, origin);

        const usage = await getDfsUsage(ip, kv);
        if (usage >= DFS_DAILY_LIMIT) {
          return jsonResponse({
            error: `Daily limit reached (${DFS_DAILY_LIMIT} queries). Enter your own DataForSEO API key for unlimited access.`,
            limit: DFS_DAILY_LIMIT, used: usage, needsKey: true,
          }, 429, origin);
        }

        dfsAuth = ourKey;
        await incrementDfsUsage(ip, kv);
      }

      // Forward request to DataForSEO
      if (request.method !== 'GET' && request.method !== 'POST') {
        return jsonResponse({ error: 'Method not allowed' }, 405, origin);
      }

      let body;
      if (request.method === 'POST') {
        body = await request.text();
      } else {
        // GET: build body from query params
        const data = url.searchParams.get('data');
        body = data || '[]';
      }

      try {
        const dfsResp = await fetch(`https://api.dataforseo.com/v3/${endpoint}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Basic ${dfsAuth}`,
          },
          body,
        });
        const result = await dfsResp.json();

        // Return remaining quota info
        const remaining = userKey ? 'unlimited' : (DFS_DAILY_LIMIT - (await getDfsUsage(ip, env.RATE_LIMITS)));

        return jsonResponse({
          ...result,
          _lumina: { remaining, limit: userKey ? null : DFS_DAILY_LIMIT, ownKey: !!userKey },
        }, dfsResp.status, origin);
      } catch (err) {
        return jsonResponse({ error: 'DataForSEO request failed: ' + err.message }, 502, origin);
      }
    }

    return jsonResponse({ error: 'Not found. Try: /fetch, /check, /headers, /deep, /screenshot, /redirect, /dfs' }, 404, origin);
  }
};
