// Lumina SEO — CORS Fetch Proxy + Bot Check + Headers + Deep Scan Worker v4.0
// Worker: lumina-proxy.julien-elbahy.workers.dev
//
// Endpoints:
//   GET /fetch?url=...          → Fetch HTML (existing)
//   GET /check?url=...&bot=...  → Bot server check (existing)
//   GET /headers?url=...        → Response headers + HTTP status
//   GET /deep?url=...           → JS-rendered HTML via Cloudflare Browser Rendering
//   GET /screenshot?url=...     → Screenshot via Cloudflare Browser Rendering
//   GET /                       → Health check

const ALLOWED_ORIGINS = [
  'https://lumina-seo.com',
  'https://www.lumina-seo.com',
  'https://lumina-website-01p.pages.dev',
  'http://localhost:8080',
  'http://localhost:3000',
  'http://127.0.0.1:8080',
];

const BLOCKED_HOSTS = [
  'localhost', '127.0.0.1', '0.0.0.0', '10.', '172.16.', '172.17.', '172.18.',
  '172.19.', '172.20.', '172.21.', '172.22.', '172.23.', '172.24.', '172.25.',
  '172.26.', '172.27.', '172.28.', '172.29.', '172.30.', '172.31.', '192.168.',
  'workers.dev', 'lumina-proxy',
];

// All 24 bots — grouped by category
const BOT_AGENTS = {
  'googlebot':          'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
  'bingbot':            'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)',
  'duckduckbot':        'Mozilla/5.0 (compatible; DuckDuckBot/1.0; +https://duckduckgo.com/duckduckbot)',
  'yandexbot':          'Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)',
  'baiduspider':        'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)',
  'gptbot':             'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.0; +https://openai.com/gptbot)',
  'oai-searchbot':      'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; OAI-SearchBot/1.0; +https://openai.com/searchbot)',
  'chatgpt-user':       'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; ChatGPT-User/1.0; +https://openai.com/bot)',
  'claudebot':          'Mozilla/5.0 (compatible; ClaudeBot/1.0; +https://anthropic.com/claudebot)',
  'claude-searchbot':   'Mozilla/5.0 (compatible; Claude-SearchBot/1.0; +https://anthropic.com/claude-searchbot)',
  'claude-user':        'Mozilla/5.0 (compatible; Claude-User/1.0; +https://anthropic.com/claude-user)',
  'perplexitybot':      'Mozilla/5.0 (compatible; PerplexityBot/1.0; +https://www.perplexity.ai/perplexitybot)',
  'google-extended':    'Mozilla/5.0 (compatible; Google-Extended; +http://www.google.com/bot.html)',
  'xai-web-crawler':    'Mozilla/5.0 (compatible; xAI-Web-Crawler/1.0; +https://x.ai/crawler)',
  'mistralai-user':     'Mozilla/5.0 (compatible; MistralAI-User/1.0; +https://mistral.ai)',
  'applebot-extended':  'Mozilla/5.0 (compatible; Applebot-Extended/0.1; +http://www.apple.com/go/applebot)',
  'ccbot':              'CCBot/2.0 (https://commoncrawl.org/faq/)',
  'cohere-ai':          'CohereBot/1.0 (+https://cohere.com/)',
  'bytespider':         'Mozilla/5.0 (Linux; Android 5.0) AppleWebKit/537.36 (compatible; Bytespider; https://zhanzhang.toutiao.com/)',
  'meta-external':      'Mozilla/5.0 (compatible; Meta-ExternalAgent/1.0; +https://developers.facebook.com/docs/sharing/webmasters/crawler)',
  'applebot':           'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/600.2.5 (compatible; Applebot/0.1; +http://www.apple.com/go/applebot)',
  'amazonbot':          'Mozilla/5.0 (compatible; Amazonbot/0.1; +https://developer.amazon.com/support/amazonbot)',
  'bravebot':           'Mozilla/5.0 (compatible; BraveBot/1.0; +https://brave.com/)',
  'youbot':             'Mozilla/5.0 (compatible; YouBot/1.0; +https://you.com)',
};

// ── Rate Limiter ──
const rateLimitMap = new Map();
const RATE_LIMIT = 30;
const RATE_WINDOW = 60_000;

function isRateLimited(ip) {
  const now = Date.now();
  const entry = rateLimitMap.get(ip);
  if (!entry || now - entry.start > RATE_WINDOW) {
    rateLimitMap.set(ip, { start: now, count: 1 });
    if (rateLimitMap.size > 10000) {
      for (const [key, val] of rateLimitMap) {
        if (now - val.start > RATE_WINDOW) rateLimitMap.delete(key);
      }
    }
    return false;
  }
  entry.count++;
  return entry.count > RATE_LIMIT;
}

function isAllowedOrigin(origin) {
  if (!origin) return false;
  if (origin.startsWith('chrome-extension://')) return true;
  return ALLOWED_ORIGINS.some(o => origin.startsWith(o));
}

function getCorsHeaders(origin) {
  return {
    'Access-Control-Allow-Origin': isAllowedOrigin(origin) ? origin : 'https://lumina-seo.com',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Max-Age': '86400',
  };
}

function jsonResponse(data, status, origin) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...getCorsHeaders(origin) },
  });
}

function validateTargetUrl(targetUrl) {
  if (!targetUrl) return { error: 'Missing ?url=' };
  let parsed;
  try {
    parsed = new URL(targetUrl);
    if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error();
  } catch {
    return { error: 'Invalid URL' };
  }
  if (BLOCKED_HOSTS.some(h => parsed.hostname.startsWith(h) || parsed.hostname.includes(h))) {
    return { error: 'Blocked host' };
  }
  return { parsed };
}

// ── Cloudflare Account ID (for Browser Rendering REST API) ──
const CF_ACCOUNT_ID = '045957bc690a89607c5ced094e3d11e4';

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';

    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: getCorsHeaders(origin) });
    }

    if (request.method !== 'GET') {
      return jsonResponse({ error: 'Method not allowed' }, 405, origin);
    }

    const url = new URL(request.url);

    // ══════════════════════════════════════════
    //  Health Check
    // ══════════════════════════════════════════
    if (url.pathname === '/' || url.pathname === '/health') {
      return jsonResponse({
        status: 'ok',
        service: 'lumina-proxy',
        version: '4.0',
        bots: Object.keys(BOT_AGENTS).length,
        endpoints: ['/fetch', '/check', '/headers', '/deep', '/screenshot'],
      }, 200, origin);
    }

    // ══════════════════════════════════════════
    //  /check — Bot Server Check (unchanged)
    // ══════════════════════════════════════════
    if (url.pathname === '/check') {
      const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
      if (isRateLimited(ip)) return jsonResponse({ error: 'Rate limited.' }, 429, origin);

      const targetUrl = url.searchParams.get('url');
      const bot = (url.searchParams.get('bot') || 'googlebot').toLowerCase();
      const { error, parsed } = validateTargetUrl(targetUrl);
      if (error) return jsonResponse({ error }, 400, origin);

      const userAgent = BOT_AGENTS[bot] || BOT_AGENTS['googlebot'];
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 10000);

      try {
        const resp = await fetch(parsed.href, {
          method: 'GET',
          headers: { 'User-Agent': userAgent },
          redirect: 'follow',
          signal: controller.signal,
        });
        clearTimeout(timeout);
        return jsonResponse({ statusCode: resp.status, statusText: resp.statusText, bot, url: parsed.href }, 200, origin);
      } catch (err) {
        clearTimeout(timeout);
        return jsonResponse({ statusCode: 0, bot, error: err.name === 'AbortError' ? 'Timeout (10s)' : err.message }, 200, origin);
      }
    }

    // ══════════════════════════════════════════
    //  /fetch — HTML Fetch Proxy (unchanged)
    // ══════════════════════════════════════════
    if (url.pathname === '/fetch') {
      const validOrigin = isAllowedOrigin(origin);
      const referer = request.headers.get('Referer') || '';
      const validReferer = ALLOWED_ORIGINS.some(o => referer.startsWith(o));
      if (!validOrigin && !validReferer) return jsonResponse({ error: 'Forbidden' }, 403, origin);

      const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
      if (isRateLimited(ip)) return jsonResponse({ error: 'Rate limited.' }, 429, origin);

      const targetUrl = url.searchParams.get('url');
      const { error, parsed } = validateTargetUrl(targetUrl);
      if (error) return jsonResponse({ error }, 400, origin);

      const start = Date.now();
      try {
        const resp = await fetch(parsed.href, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (compatible; LuminaSEO/1.0; +https://lumina-seo.com)',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9,de;q=0.8',
          },
          redirect: 'follow',
          cf: { cacheTtl: 300, cacheEverything: true },
        });

        const ct = resp.headers.get('Content-Type') || '';
        if (!ct.includes('text/') && !ct.includes('html') && !ct.includes('xml')) {
          return jsonResponse({ error: 'Not HTML', contentType: ct }, 400, origin);
        }

        const html = await resp.text();
        if (html.length > 2_000_000) return jsonResponse({ error: 'Page too large' }, 400, origin);

        return jsonResponse({ html, status: resp.status, url: resp.url, time: Date.now() - start }, 200, origin);
      } catch (err) {
        return jsonResponse({ error: 'Fetch failed: ' + err.message }, 502, origin);
      }
    }

    // ══════════════════════════════════════════
    //  /headers — Response Headers + Security Check
    // ══════════════════════════════════════════
    if (url.pathname === '/headers') {
      const validOrigin = isAllowedOrigin(origin);
      const referer = request.headers.get('Referer') || '';
      const validReferer = ALLOWED_ORIGINS.some(o => referer.startsWith(o));
      if (!validOrigin && !validReferer) return jsonResponse({ error: 'Forbidden' }, 403, origin);

      const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
      if (isRateLimited(ip)) return jsonResponse({ error: 'Rate limited.' }, 429, origin);

      const targetUrl = url.searchParams.get('url');
      const { error, parsed } = validateTargetUrl(targetUrl);
      if (error) return jsonResponse({ error }, 400, origin);

      const start = Date.now();
      try {
        const resp = await fetch(parsed.href, {
          method: 'HEAD',
          headers: {
            'User-Agent': 'Mozilla/5.0 (compatible; LuminaSEO/1.0; +https://lumina-seo.com)',
          },
          redirect: 'follow',
        });

        // Collect all response headers
        const headers = {};
        for (const [key, value] of resp.headers.entries()) {
          headers[key.toLowerCase()] = value;
        }

        // Extract security-relevant headers
        const security = {
          hsts: headers['strict-transport-security'] || null,
          csp: headers['content-security-policy'] || null,
          xFrameOptions: headers['x-frame-options'] || null,
          xContentType: headers['x-content-type-options'] || null,
          referrerPolicy: headers['referrer-policy'] || null,
          permissionsPolicy: headers['permissions-policy'] || null,
          xXssProtection: headers['x-xss-protection'] || null,
          crossOriginOpenerPolicy: headers['cross-origin-opener-policy'] || null,
          crossOriginEmbedderPolicy: headers['cross-origin-embedder-policy'] || null,
          crossOriginResourcePolicy: headers['cross-origin-resource-policy'] || null,
        };

        // Extract server/tech info
        const tech = {
          server: headers['server'] || null,
          poweredBy: headers['x-powered-by'] || null,
          generator: headers['x-generator'] || null,
          via: headers['via'] || null,
          cdn: headers['x-cdn'] || headers['x-cache'] || null,
          cfRay: headers['cf-ray'] || null,
        };

        // Redirect info
        const redirectInfo = {
          finalUrl: resp.url,
          redirected: resp.url !== parsed.href,
          statusCode: resp.status,
        };

        return jsonResponse({
          url: parsed.href,
          statusCode: resp.status,
          statusText: resp.statusText,
          security,
          tech,
          redirect: redirectInfo,
          headers,
          time: Date.now() - start,
        }, 200, origin);
      } catch (err) {
        return jsonResponse({ error: 'Headers fetch failed: ' + err.message }, 502, origin);
      }
    }

    // ══════════════════════════════════════════
    //  /deep — JS-rendered HTML via Browser Rendering
    // ══════════════════════════════════════════
    if (url.pathname === '/deep') {
      const validOrigin = isAllowedOrigin(origin);
      const referer = request.headers.get('Referer') || '';
      const validReferer = ALLOWED_ORIGINS.some(o => referer.startsWith(o));
      if (!validOrigin && !validReferer) return jsonResponse({ error: 'Forbidden' }, 403, origin);

      const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
      if (isRateLimited(ip)) return jsonResponse({ error: 'Rate limited.' }, 429, origin);

      const targetUrl = url.searchParams.get('url');
      const { error, parsed } = validateTargetUrl(targetUrl);
      if (error) return jsonResponse({ error }, 400, origin);

      // Get API token from environment secret
      const apiToken = env.CF_BR_TOKEN;
      if (!apiToken) {
        return jsonResponse({ error: 'Browser Rendering not configured. Set CF_BR_TOKEN secret.' }, 500, origin);
      }

      const start = Date.now();
      try {
        const brResp = await fetch(
          `https://api.cloudflare.com/client/v4/accounts/${CF_ACCOUNT_ID}/browser-rendering/content`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${apiToken}`,
            },
            body: JSON.stringify({
              url: parsed.href,
              goToOptions: { waitUntil: 'networkidle2', timeout: 15000 },
              rejectResourceTypes: ['image', 'media', 'font'],
            }),
          }
        );

        if (!brResp.ok) {
          const errText = await brResp.text();
          return jsonResponse({ error: 'Browser Rendering error: ' + brResp.status, detail: errText.substring(0, 200) }, 502, origin);
        }

        const html = await brResp.text();
        if (html.length > 3_000_000) {
          return jsonResponse({ error: 'Rendered page too large' }, 400, origin);
        }

        return jsonResponse({
          html,
          rendered: true,
          url: parsed.href,
          time: Date.now() - start,
          browserMs: parseInt(brResp.headers.get('X-Browser-Ms-Used') || '0'),
        }, 200, origin);
      } catch (err) {
        return jsonResponse({ error: 'Deep scan failed: ' + err.message }, 502, origin);
      }
    }

    // ══════════════════════════════════════════
    //  /screenshot — Screenshot via Browser Rendering
    // ══════════════════════════════════════════
    if (url.pathname === '/screenshot') {
      const validOrigin = isAllowedOrigin(origin);
      const referer = request.headers.get('Referer') || '';
      const validReferer = ALLOWED_ORIGINS.some(o => referer.startsWith(o));
      if (!validOrigin && !validReferer) return jsonResponse({ error: 'Forbidden' }, 403, origin);

      const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
      if (isRateLimited(ip)) return jsonResponse({ error: 'Rate limited.' }, 429, origin);

      const targetUrl = url.searchParams.get('url');
      const { error, parsed } = validateTargetUrl(targetUrl);
      if (error) return jsonResponse({ error }, 400, origin);

      const apiToken = env.CF_BR_TOKEN;
      if (!apiToken) {
        return jsonResponse({ error: 'Browser Rendering not configured.' }, 500, origin);
      }

      const device = (url.searchParams.get('device') || 'desktop').toLowerCase();
      const viewport = device === 'mobile'
        ? { width: 390, height: 844, deviceScaleFactor: 2 }
        : device === 'tablet'
          ? { width: 834, height: 1194, deviceScaleFactor: 2 }
          : { width: 1440, height: 900, deviceScaleFactor: 1 };

      try {
        const brResp = await fetch(
          `https://api.cloudflare.com/client/v4/accounts/${CF_ACCOUNT_ID}/browser-rendering/screenshot`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${apiToken}`,
            },
            body: JSON.stringify({
              url: parsed.href,
              goToOptions: { waitUntil: 'networkidle2', timeout: 20000 },
              viewport,
              screenshotOptions: {
                fullPage: url.searchParams.get('full') === '1',
                type: 'png',
              },
            }),
          }
        );

        if (!brResp.ok) {
          const errText = await brResp.text();
          return jsonResponse({ error: 'Screenshot error: ' + brResp.status }, 502, origin);
        }

        // Return the PNG image directly
        const imgData = await brResp.arrayBuffer();
        return new Response(imgData, {
          status: 200,
          headers: {
            'Content-Type': 'image/png',
            'Cache-Control': 'public, max-age=300',
            ...getCorsHeaders(origin),
          },
        });
      } catch (err) {
        return jsonResponse({ error: 'Screenshot failed: ' + err.message }, 502, origin);
      }
    }

    return jsonResponse({ error: 'Not found. Endpoints: /fetch, /check, /headers, /deep, /screenshot' }, 404, origin);
  }
};
