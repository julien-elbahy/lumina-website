# Lumina Worker v5 — Deployment Guide

## Endpoints
| Endpoint | Beschreibung | Kosten |
|---|---|---|
| `/fetch?url=` | Raw HTML | Kostenlos |
| `/check?url=&bot=` | Bot-Status prüfen | Kostenlos |
| `/headers?url=` | Response-Headers + Security | Kostenlos |
| `/deep?url=` | JS-gerenderten HTML (Browser Rendering) | $5/Mo (10h) |
| `/screenshot?url=&device=&full=` | Screenshot | $5/Mo |
| `/redirect?url=` | Redirect-Kette verfolgen | Kostenlos |
| `/dfs?endpoint=&data=` | DataForSEO Proxy (5/Tag oder eigener Key) | ~$30/Mo max |

## Schritt 1: Workers Paid Plan aktivieren
1. https://dash.cloudflare.com → Workers & Pages → Plans
2. "Workers Paid" aktivieren ($5/Monat)

## Schritt 2: Browser Rendering API Token
1. https://dash.cloudflare.com/profile/api-tokens
2. "Create Token" → "Custom Token"
3. Permissions: `Account` → `Browser Rendering` → `Edit`
4. Token kopieren

## Schritt 3: DataForSEO Account (optional, für SERP/Keywords)
1. https://app.dataforseo.com/ → Account erstellen
2. API Login + Passwort → Base64 kodieren:
   `echo -n "login:password" | base64`
3. Ergebnis ist dein DFS_API_KEY

## Schritt 4: Worker-Code deployen
1. Workers & Pages → lumina-proxy → "Edit Code"
2. Code durch `worker-v5.js` ersetzen
3. "Save and Deploy"

## Schritt 5: Secrets setzen
Workers & Pages → lumina-proxy → Settings → Variables & Secrets:

| Name | Typ | Wert |
|---|---|---|
| `CF_BR_TOKEN` | Secret | Browser Rendering API Token |
| `DFS_API_KEY` | Secret | Base64-kodierter DataForSEO Login (optional) |

## Schritt 6: KV Namespace binden
1. lumina-proxy → Settings → Bindings
2. "Add Binding" → KV Namespace
3. Variable name: `RATE_LIMITS`
4. KV Namespace: `lumina-rate-limits` (ID: 644e6c9b6ca448e992607aa68b1c4064)

## Testen
```bash
# Health
curl https://lumina-proxy.julien-elbahy.workers.dev/

# Headers (funktioniert sofort)
curl "https://lumina-proxy.julien-elbahy.workers.dev/headers?url=https://lumina-seo.com"

# Redirect Chain
curl "https://lumina-proxy.julien-elbahy.workers.dev/redirect?url=http://lumina-seo.com"

# Deep Scan (nach BR Token Setup)
curl "https://lumina-proxy.julien-elbahy.workers.dev/deep?url=https://lumina-seo.com"

# DataForSEO (nach DFS Key Setup)
curl "https://lumina-proxy.julien-elbahy.workers.dev/dfs?endpoint=serp/google/organic/live/regular" \
  -d '[{"keyword":"seo tool","location_code":2040,"language_code":"de","depth":10}]'
```

## Kosten-Übersicht
| Posten | Monatlich |
|---|---|
| Workers Paid | $5 |
| Browser Rendering (10h inkl.) | $0 |
| BR über 10h | $0.09/h |
| DataForSEO (~500 Abfragen) | ~$1 |
| **Gesamt (normal)** | **~$6** |
| **Gesamt (viel Traffic)** | **~$15-30** |
